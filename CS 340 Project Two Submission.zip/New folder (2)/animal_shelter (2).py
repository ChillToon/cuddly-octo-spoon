# Imports the necessary libraries
from pymongo import MongoClient 

# Import ObjectId for handling MongoDB document IDs
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'passw0rd1' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            try:
                # Insert the data into the collection; data should be a dictionary
                self.collection.insert_one(data)
                return True  # Return True if insertion is successful
            except errors.PyMongoError as e:
                # Handle errors that occur during insertion
                print(f"An error occurred while inserting data: {e}")
                return False  # Return False if an error occurs
        else:
            # Raise a ValueError if the data parameter is empty
            raise ValueError("Data parameter is empty")
            
    # Complete this create method to implement the R in CRUD. 
    def read(self, data):
        # Method to read documents from the collection
        if data is not None:
            try:
                # Find documents in the collection that match the query
                documents = list(self.collection.find(data))
                return documents  # Return the list of documents
            except errors.PyMongoError as e:
                # Handle errors that occur during the read operation
                print(f"An error occurred while reading data: {e}")
                return []  # Return an empty list if an error occurs
        else:
            # Raise a ValueError if the query parameter is empty
            raise ValueError("Query parameter is empty")
            
            self.database.animals.insert_one(data)  # data should be dictionary 
            
           # Complete this create method to implement the U in CRUD.  
    def update(self, searchData, updateData):
        if searchData is not None:
            result = self.database.animals.update_mant(searchData, { "set" : updateData })
        else:
            return "{}"
        # Return the dataset else let the error flow up
        return result.raw_result
    
            # Create method to implement the D in CRUD.
    def delete(self, deleteData):
        if deleteData is not None:
            result = self.database.animals.delete_many(deleteData)
        else:
                return "{}"
            # Return the dataset else let error flow ip
        return result.raw_result